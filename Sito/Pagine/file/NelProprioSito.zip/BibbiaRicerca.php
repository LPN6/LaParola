<?
$versione = (isset($_REQUEST["versione"])?$_REQUEST["versione"]:"Nuova Riveduta");
$brano = (isset($_REQUEST["brano"])?$_REQUEST["brano"]:"");
$frase = (isset($_REQUEST["frase"])?$_REQUEST["frase"]:"");
?>
<html>
<body>
<?
include(str_replace(" ","+","http://www.laparola.net/ricerca_testo.php?frase=".$frase."&versione=".$versione."&brano=".$brano));
?>
</body>
</html>