<?
$riferimento = (isset($_REQUEST["riferimento"])?$_REQUEST["riferimento"]:"Genesi 1:1");
if (isset($_REQUEST["versioni"]))
  $versioni = $_REQUEST["versioni"];
?>
<html>
<body>
<?
$listaVersioni="";
$nVersioni = count($versioni);
for ($i=0; $i<$nVersioni; $i++) {
  $listaVersioni .= "&versioni[]=".$versioni[$i];
}
include(str_replace(" ","+","http://www.laparola.net/inserisci_testo.php?riferimento=".$riferimento.$listaVersioni));
?>
</body>
</html>