<html>
<head>
</head>
<body>
<center><table border="1" cellpadding="9">
<tr><td width="50%" valign="top">
<p><b>Visualizzare un brano</b></p>
<form action="http://www.laparola.net/BibbiaTesto.php" method="post" onsubmit="if (riferimento.value.length==0) {alert('Digitare il riferimento di un brano')}; return riferimento.value.length!=0;">
<p>Brano da visualizzare:<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="riferimento"></p>
<p>Versione/i da visualizzare:<br>
<select multiple name="versioni[]" size="7">
<option selected value="Nuova Riveduta">Nuova Riveduta
<option value="C.E.I.">C.E.I./Gerusalemme
<option value="Nuova Diodati">Nuova Diodati
<option value="Riveduta">Luzzi/Riveduta
<option value="Diodati">Diodati
<option value="Commentario">Commentario di Gen-Lev e il NT
<option value="Riferimenti incrociati">Riferimenti incrociati
</select></p>
<input type="submit" name="Submit" value="Visualizza testo">
<input type="reset" name="Reset" value="Annulla">
<p><a href="http://www.laparola.net/aiutovis.php">Aiuto per visualizzare un brano della Bibbia</a></p>
</form>
</td><td valign="top">
<form action="http://www.laparola.net/BibbiaRicerca.php" method="post" onsubmit="if (frase.value.length==0) {alert('Digitare una parola o espressione da ricercare')}; return frase.value.length!=0;">
<p><b>Ricercare un'espressione</b></p>
<p>Parola o frase da ricercare:<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="frase"></p>
<p>Versione da ricercare:<br>
<select name="versione" size="5">
<option selected value="Nuova Riveduta">Nuova Riveduta
<option value="C.E.I.">C.E.I./Gerusalemme
<option value="Nuova Diodati">Nuova Diodati
<option value="Riveduta">Luzzi/Riveduta
<option value="Diodati">Diodati
</select></p>
<p>Brano da ricercare:<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="brano"></p>
<input type="submit" name="Submit" value="Ricerca">
<input type="reset" name="Reset" value="Annulla">
<p><a href="http://www.laparola.net/aiutoric.php">Aiuto per ricercare un'espressione della Bibbia</a></p>
</form>
</td></tr></table>
<p>Un servizio di <a href="http://www.laparola.net/" title="La Bibbia">La Bibbia</a>.</p>
</center>
</body></html>
